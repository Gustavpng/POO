package graficotn1;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Semaforo extends JPanel  {

    private int state1, state2; // estados dos semáforos: 0 - verde, 1 - amarelo, 2 - vermelho

    public Semaforo() {
        state1 = 0; // Inicia com verde
        state2 = 2; // Inicia com vermelho

        // Inicia as threads para os semáforos
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    switch (state1) {
                        case 0: // verde
                            repaint();
                            try {
                                Thread.sleep(5000); // Aguarda 5 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state1 = 1; // muda para amarelo
                            break;
                        case 1: // amarelo
                            repaint();
                            try {
                                Thread.sleep(3000); // Aguarda 3 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state1 = 2; // muda para vermelho
                            break;
                        case 2: // vermelho
                            repaint();
                            try {
                                Thread.sleep(5000); // Aguarda 5 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state1 = 3; // muda para amarelo
                            break;
                        case 3: // amarelo
                            repaint();
                            try {
                                Thread.sleep(3000); // Aguarda 3 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state1 = 0; // muda para verde
                            break;
                    }
                }
            }
        }).start();

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    switch (state2) {
                        case 0: // verde
                            repaint();
                            try {
                                Thread.sleep(5000); // Aguarda 5 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state2 = 1; // muda para amarelo
                            break;
                        case 1: // amarelo
                            repaint();
                            try {
                                Thread.sleep(3000); // Aguarda 3 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state2 = 2; // muda para vermelho
                            break;
                        case 2: // vermelho
                            repaint();
                            try {
                                Thread.sleep(5000); // Aguarda 5 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state2 = 3; // muda para amarelo
                            break;
                        case 3: // amarelo
                            repaint();
                            try {
                                Thread.sleep(3000); // Aguarda 3 segundos antes de mudar de estado
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            state2 = 0; // muda para verde
                            break;
                    }
                }
            }
        }).start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawTrafficLight(g, 25, 50, state1); // desenha semáforo 1
        drawTrafficLight(g, 230, 50, state2); // desenha semáforo 2
    }

    private void drawTrafficLight(Graphics g, int x, int y, int state) {
        // Desenha o poste
        g.setColor(Color.BLACK);
        g.fillRect(x + 10, y, 20, 80);

        // Desenha o semáforo
        g.setColor(Color.GRAY);
        g.fillRoundRect(x, y + 10, 40, 100, 20, 20);

        // Define as cores dos círculos conforme o estado
        Color color1, color2, color3;
        switch (state) {
            case 0: // verde
                color1 = Color.GREEN;
                color2 = Color.GRAY;
                color3 = Color.GRAY;
                break;
            case 1: // amarelo
                color1 = Color.GRAY;
                color2 = Color.YELLOW;
                color3 = Color.GRAY;
                break;
            case 2: // vermelho
                color1 = Color.GRAY;
                color2 = Color.GRAY;
                color3 = Color.RED;
                break;
            case 3: // amarelo
                color1 = Color.GRAY;
                color2 = Color.YELLOW;
                color3 = Color.GRAY;
                break;
            default:
                color1 = Color.GRAY;
                color2 = Color.GRAY;
                color3 = Color.GRAY;
        }

        // Desenha os círculos do semáforo
        g.setColor(color1);
        g.fillOval(x + 5, y + 10, 30, 30);
        g.setColor(color2);
        g.fillOval(x + 5, y + 40, 30, 30);
        g.setColor(color3);
        g.fillOval(x + 5, y + 70, 30, 30);
    }
}
