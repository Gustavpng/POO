package graficotn1;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;

public class Principal extends JFrame implements ActionListener, MouseListener {

    private JPopupMenu puMenu;
    private JMenu menuForma;
    private JMenuItem itemForma1;
    private JMenuItem itemForma2;
    private int tipoForma = 1; // Inicializa com o tipoForma 1
    private Formato Janela;
    private Semaforo lightsPanel;
    private Digital digitalPanel; // Painel Digital adicionado

    public Principal() {
        super("Dois Semáforos");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(350, 5, 700, 720);
        setResizable(false);

        // Inicializa o semáforo
        lightsPanel = new Semaforo();
        add(lightsPanel);

        digitalPanel = new Digital();

        // Inicializa o menu popup
        puMenu = new JPopupMenu();
        menuForma = new JMenu("Formato");
        itemForma1 = new JMenuItem("Tradicional");
        itemForma2 = new JMenuItem("Digital");
        menuForma.add(itemForma1);
        menuForma.add(itemForma2);
        puMenu.add(menuForma);

        // Adiciona os listeners
        addMouseListener(this);
        itemForma1.addActionListener(this);
        itemForma2.addActionListener(this);

        // Inicializa o painel de Janela (Formato)
        Janela = new Formato(tipoForma);
        add(Janela, BorderLayout.WEST);

        // Inicializa o painel Digital e o adiciona
        digitalPanel = new Digital();
        add(digitalPanel, BorderLayout.EAST); // Adiciona à direita

        setSize(450, 250);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == itemForma1) {
            lightsPanel.setVisible(true);
            digitalPanel.setVisible(false);
            add(lightsPanel);
        } else if (e.getSource() == itemForma2) {
            digitalPanel.setVisible(true);
            lightsPanel.setVisible(false);
            add(digitalPanel);
        }
        Janela.setTipoForma(tipoForma);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON3) {
            puMenu.show(this, e.getX(), e.getY());
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Principal());
    }

    
}
