package graficotn1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JPanel;

public class Digital extends JPanel {

    private int count1; // Contadores para os semáforos

    public Digital() {
        count1 = 5; // Inicia com 5 segundos


        // Inicia a thread para atualizar os contadores
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    // Atualiza o contador 1 a cada segundo
                    do {
                        repaint(); // Redesenha o painel
                        try {
                            Thread.sleep(1000); // Espera 1 segundo
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        count1--; // Decrementa o contador
                    } while (count1 != -1); // Repete até o contador chegar a -1
                    count1 = 3; // Reinicia o contador

                    // Atualiza o contador 2 a cada segundo
                    do {
                        repaint(); // Redesenha o painel
                        try {
                            Thread.sleep(1000); // Espera 1 segundo
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        count1--; // Decrementa o contador
                    } while (count1 != -1); // Repete até o contador chegar a -1
                    count1 = 5; // Reinicia o contador
                }
            }
        }).start(); // Inicia a thread
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Define a fonte e cor para desenhar os números
        g.setFont(new Font("Arial", Font.BOLD, 40));
        g.setColor(Color.BLACK);

        // Desenha o contador 1 na posição (50, 50)
        String count1Str = String.valueOf(count1);
        g.drawString(count1Str, 130, 120);

        // Desenha o contador 2 na posição (150, 50)
        String count2Str = String.valueOf(count1);
        g.drawString(count2Str, 340, 120);
    }
}
