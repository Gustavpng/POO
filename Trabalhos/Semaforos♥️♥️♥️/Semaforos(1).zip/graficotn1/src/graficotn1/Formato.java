
package graficotn1;

    import javax.swing.*;

public class Formato extends JPanel {
    private int tipoForma;

    public Formato(int tipoForma) {
        this.tipoForma = tipoForma;
        // Inicialize aqui o que for necessário para o seu componente
    }

    public void setTipoForma(int tipoForma) {
        this.tipoForma = tipoForma;
        // Atualize o componente conforme o tipo de forma
    }

    // Implemente aqui as funcionalidades necessárias para o seu componente
}
