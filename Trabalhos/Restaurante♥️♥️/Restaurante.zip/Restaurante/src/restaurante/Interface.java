package restaurante;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Interface extends javax.swing.JFrame {

    public String nomeUsuario = null;
    public String senha = null;

    private String[] diasDaSemana = {"Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira"};
    public int indiceDiaAtual = 0; // Começa na segunda-feira (0 = segunda-feira)

    private String[][] cardapioSemana = new String[5][13];

    private void atualizarTextField() {
        DiaDaSemana.setText(diasDaSemana[indiceDiaAtual]);
    }

    private void ArmazenarCardapio() {

        //Segunda-feira
        if (indiceDiaAtual == 0) {
            cardapioSemana[0][0] = CARDAPIO_Acompanhamento1.getText();
            cardapioSemana[0][1] = CARDAPIO_Acompanhamento2.getText();

            cardapioSemana[0][2] = CARDAPIO_Prato_Principal1.getText();
            cardapioSemana[0][3] = CARDAPIO_Prato_Principal2.getText();

            cardapioSemana[0][4] = CARDAPIO_Prato_Principal_OVO1.getText();
            cardapioSemana[0][5] = CARDAPIO_Prato_Principal_OVO2.getText();

            cardapioSemana[0][6] = CARDAPIO_Complementos.getText();

            cardapioSemana[0][7] = CARDAPIO_Saladas1.getText();
            cardapioSemana[0][8] = CARDAPIO_Saladas2.getText();
            cardapioSemana[0][9] = CARDAPIO_Saladas3.getText();

            cardapioSemana[0][10] = CARDAPIO_Bebidas1.getText();
            cardapioSemana[0][11] = CARDAPIO_Bebidas2.getText();

            cardapioSemana[0][12] = CARDAPIO_Sobremesas.getText();
        }
        //Terça-feira
        if (indiceDiaAtual == 1) {
            cardapioSemana[1][0] = CARDAPIO_Acompanhamento1.getText();
            cardapioSemana[1][1] = CARDAPIO_Acompanhamento2.getText();

            cardapioSemana[1][2] = CARDAPIO_Prato_Principal1.getText();
            cardapioSemana[1][3] = CARDAPIO_Prato_Principal2.getText();

            cardapioSemana[1][4] = CARDAPIO_Prato_Principal_OVO1.getText();
            cardapioSemana[1][5] = CARDAPIO_Prato_Principal_OVO2.getText();

            cardapioSemana[1][6] = CARDAPIO_Complementos.getText();

            cardapioSemana[1][7] = CARDAPIO_Saladas1.getText();
            cardapioSemana[1][8] = CARDAPIO_Saladas2.getText();
            cardapioSemana[1][9] = CARDAPIO_Saladas3.getText();

            cardapioSemana[1][10] = CARDAPIO_Bebidas1.getText();
            cardapioSemana[1][11] = CARDAPIO_Bebidas2.getText();

            cardapioSemana[1][12] = CARDAPIO_Sobremesas.getText();
        }
        //Quarta-feira
        if (indiceDiaAtual == 2) {
            cardapioSemana[2][0] = CARDAPIO_Acompanhamento1.getText();
            cardapioSemana[2][1] = CARDAPIO_Acompanhamento2.getText();

            cardapioSemana[2][2] = CARDAPIO_Prato_Principal1.getText();
            cardapioSemana[2][3] = CARDAPIO_Prato_Principal2.getText();

            cardapioSemana[2][4] = CARDAPIO_Prato_Principal_OVO1.getText();
            cardapioSemana[2][5] = CARDAPIO_Prato_Principal_OVO2.getText();

            cardapioSemana[2][6] = CARDAPIO_Complementos.getText();

            cardapioSemana[2][7] = CARDAPIO_Saladas1.getText();
            cardapioSemana[2][8] = CARDAPIO_Saladas2.getText();
            cardapioSemana[2][9] = CARDAPIO_Saladas3.getText();

            cardapioSemana[2][10] = CARDAPIO_Bebidas1.getText();
            cardapioSemana[2][11] = CARDAPIO_Bebidas2.getText();

            cardapioSemana[2][12] = CARDAPIO_Sobremesas.getText();
        }
        //Quinta-feira
        if (indiceDiaAtual == 3) {
            cardapioSemana[3][0] = CARDAPIO_Acompanhamento1.getText();
            cardapioSemana[3][1] = CARDAPIO_Acompanhamento2.getText();

            cardapioSemana[3][2] = CARDAPIO_Prato_Principal1.getText();
            cardapioSemana[3][3] = CARDAPIO_Prato_Principal2.getText();

            cardapioSemana[3][4] = CARDAPIO_Prato_Principal_OVO1.getText();
            cardapioSemana[3][5] = CARDAPIO_Prato_Principal_OVO2.getText();

            cardapioSemana[3][6] = CARDAPIO_Complementos.getText();

            cardapioSemana[3][7] = CARDAPIO_Saladas1.getText();
            cardapioSemana[3][8] = CARDAPIO_Saladas2.getText();
            cardapioSemana[3][9] = CARDAPIO_Saladas3.getText();

            cardapioSemana[3][10] = CARDAPIO_Bebidas1.getText();
            cardapioSemana[3][11] = CARDAPIO_Bebidas2.getText();

            cardapioSemana[3][12] = CARDAPIO_Sobremesas.getText();
        }
        //Sexta-feira
        if (indiceDiaAtual == 4) {
            cardapioSemana[4][0] = CARDAPIO_Acompanhamento1.getText();
            cardapioSemana[4][1] = CARDAPIO_Acompanhamento2.getText();

            cardapioSemana[4][2] = CARDAPIO_Prato_Principal1.getText();
            cardapioSemana[4][3] = CARDAPIO_Prato_Principal2.getText();

            cardapioSemana[4][4] = CARDAPIO_Prato_Principal_OVO1.getText();
            cardapioSemana[4][5] = CARDAPIO_Prato_Principal_OVO2.getText();

            cardapioSemana[4][6] = CARDAPIO_Complementos.getText();

            cardapioSemana[4][7] = CARDAPIO_Saladas1.getText();
            cardapioSemana[4][8] = CARDAPIO_Saladas2.getText();
            cardapioSemana[4][9] = CARDAPIO_Saladas3.getText();

            cardapioSemana[4][10] = CARDAPIO_Bebidas1.getText();
            cardapioSemana[4][11] = CARDAPIO_Bebidas2.getText();

            cardapioSemana[4][12] = CARDAPIO_Sobremesas.getText();
        }

    }

    private void AtualizarCardapio() {

        //Segunda-feira
        if (indiceDiaAtual == 0) {
            CARDAPIO_Acompanhamento1.setText(cardapioSemana[0][0]);
            CARDAPIO_Acompanhamento2.setText(cardapioSemana[0][1]);

            CARDAPIO_Prato_Principal1.setText(cardapioSemana[0][2]);
            CARDAPIO_Prato_Principal2.setText(cardapioSemana[0][3]);

            CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[0][4]);
            CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[0][5]);

            CARDAPIO_Complementos.setText(cardapioSemana[0][6]);

            CARDAPIO_Saladas1.setText(cardapioSemana[0][7]);
            CARDAPIO_Saladas2.setText(cardapioSemana[0][8]);
            CARDAPIO_Saladas3.setText(cardapioSemana[0][9]);

            CARDAPIO_Bebidas1.setText(cardapioSemana[0][10]);
            CARDAPIO_Bebidas2.setText(cardapioSemana[0][11]);

            CARDAPIO_Sobremesas.setText(cardapioSemana[0][12]);
        }
        //Terça-feira
        if (indiceDiaAtual == 1) {
            CARDAPIO_Acompanhamento1.setText(cardapioSemana[1][0]);
            CARDAPIO_Acompanhamento2.setText(cardapioSemana[1][1]);

            CARDAPIO_Prato_Principal1.setText(cardapioSemana[1][2]);
            CARDAPIO_Prato_Principal2.setText(cardapioSemana[1][3]);

            CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[1][4]);
            CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[1][5]);

            CARDAPIO_Complementos.setText(cardapioSemana[1][6]);

            CARDAPIO_Saladas1.setText(cardapioSemana[1][7]);
            CARDAPIO_Saladas2.setText(cardapioSemana[1][8]);
            CARDAPIO_Saladas3.setText(cardapioSemana[1][9]);

            CARDAPIO_Bebidas1.setText(cardapioSemana[1][10]);
            CARDAPIO_Bebidas2.setText(cardapioSemana[1][11]);

            CARDAPIO_Sobremesas.setText(cardapioSemana[1][12]);
        }
        //Quarta-feira
        if (indiceDiaAtual == 2) {
            CARDAPIO_Acompanhamento1.setText(cardapioSemana[2][0]);
            CARDAPIO_Acompanhamento2.setText(cardapioSemana[2][1]);

            CARDAPIO_Prato_Principal1.setText(cardapioSemana[2][2]);
            CARDAPIO_Prato_Principal2.setText(cardapioSemana[2][3]);

            CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[2][4]);
            CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[2][5]);

            CARDAPIO_Complementos.setText(cardapioSemana[2][6]);

            CARDAPIO_Saladas1.setText(cardapioSemana[2][7]);
            CARDAPIO_Saladas2.setText(cardapioSemana[2][8]);
            CARDAPIO_Saladas3.setText(cardapioSemana[2][9]);

            CARDAPIO_Bebidas1.setText(cardapioSemana[2][10]);
            CARDAPIO_Bebidas2.setText(cardapioSemana[2][11]);

            CARDAPIO_Sobremesas.setText(cardapioSemana[2][12]);
        }
        //Quinta-feira
        if (indiceDiaAtual == 3) {
            CARDAPIO_Acompanhamento1.setText(cardapioSemana[3][0]);
            CARDAPIO_Acompanhamento2.setText(cardapioSemana[3][1]);

            CARDAPIO_Prato_Principal1.setText(cardapioSemana[3][2]);
            CARDAPIO_Prato_Principal2.setText(cardapioSemana[3][3]);

            CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[3][4]);
            CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[3][5]);

            CARDAPIO_Complementos.setText(cardapioSemana[3][6]);

            CARDAPIO_Saladas1.setText(cardapioSemana[3][7]);
            CARDAPIO_Saladas2.setText(cardapioSemana[3][8]);
            CARDAPIO_Saladas3.setText(cardapioSemana[3][9]);

            CARDAPIO_Bebidas1.setText(cardapioSemana[3][10]);
            CARDAPIO_Bebidas2.setText(cardapioSemana[3][11]);

            CARDAPIO_Sobremesas.setText(cardapioSemana[3][12]);
        }
        //Quinta-feira
        if (indiceDiaAtual == 4) {
            CARDAPIO_Acompanhamento1.setText(cardapioSemana[4][0]);
            CARDAPIO_Acompanhamento2.setText(cardapioSemana[4][1]);

            CARDAPIO_Prato_Principal1.setText(cardapioSemana[4][2]);
            CARDAPIO_Prato_Principal2.setText(cardapioSemana[4][3]);

            CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[4][4]);
            CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[4][5]);

            CARDAPIO_Complementos.setText(cardapioSemana[4][6]);

            CARDAPIO_Saladas1.setText(cardapioSemana[4][7]);
            CARDAPIO_Saladas2.setText(cardapioSemana[4][8]);
            CARDAPIO_Saladas3.setText(cardapioSemana[4][9]);

            CARDAPIO_Bebidas1.setText(cardapioSemana[4][10]);
            CARDAPIO_Bebidas2.setText(cardapioSemana[4][11]);

            CARDAPIO_Sobremesas.setText(cardapioSemana[4][12]);

        }
    }

    private void LimparCardapio() {

        for (int dia = 0; dia < 5; dia++) {
            // Itera sobre os tipos de cardápio (acompanhamento, prato principal, etc.)
            for (int tipo = 0; tipo < 13; tipo++) {
                // Verifica se o tipo de cardápio tem campos associados
                // Atualiza o texto do campo com base no cardápio da semana
                cardapioSemana[dia][tipo] = " ";
            }
        }
    }

    private void LimparDiaCardapio() {

        if (indiceDiaAtual == 0) {
            for (int tipo = 0; tipo < 13; tipo++) {
                cardapioSemana[0][tipo] = " ";
            }
            AtualizarCardapio();
        }

        if (indiceDiaAtual == 1) {
            for (int tipo = 0; tipo < 13; tipo++) {
                cardapioSemana[1][tipo] = " ";
            }
            AtualizarCardapio();
        }

        if (indiceDiaAtual == 2) {
            for (int tipo = 0; tipo < 13; tipo++) {
                cardapioSemana[2][tipo] = " ";
            }
            AtualizarCardapio();
        }

        if (indiceDiaAtual == 3) {
            for (int tipo = 0; tipo < 13; tipo++) {
                cardapioSemana[3][tipo] = " ";
            }
            AtualizarCardapio();
        }

        if (indiceDiaAtual == 4) {
            for (int tipo = 0; tipo < 13; tipo++) {
                cardapioSemana[4][tipo] = " ";
            }
            AtualizarCardapio();
        }

    }

    private void MostrarCardapioLimpo() {

        //Segunda-feira
        CARDAPIO_Acompanhamento1.setText(cardapioSemana[0][0]);
        CARDAPIO_Acompanhamento2.setText(cardapioSemana[0][1]);

        CARDAPIO_Prato_Principal1.setText(cardapioSemana[0][2]);
        CARDAPIO_Prato_Principal2.setText(cardapioSemana[0][3]);

        CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[0][4]);
        CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[0][5]);

        CARDAPIO_Complementos.setText(cardapioSemana[0][6]);

        CARDAPIO_Saladas1.setText(cardapioSemana[0][7]);
        CARDAPIO_Saladas2.setText(cardapioSemana[0][8]);
        CARDAPIO_Saladas3.setText(cardapioSemana[0][9]);

        CARDAPIO_Bebidas1.setText(cardapioSemana[0][10]);
        CARDAPIO_Bebidas2.setText(cardapioSemana[0][11]);

        CARDAPIO_Sobremesas.setText(cardapioSemana[0][12]);

        //Terça-feira
        CARDAPIO_Acompanhamento1.setText(cardapioSemana[1][0]);
        CARDAPIO_Acompanhamento2.setText(cardapioSemana[1][1]);

        CARDAPIO_Prato_Principal1.setText(cardapioSemana[1][2]);
        CARDAPIO_Prato_Principal2.setText(cardapioSemana[1][3]);

        CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[1][4]);
        CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[1][5]);

        CARDAPIO_Complementos.setText(cardapioSemana[1][6]);

        CARDAPIO_Saladas1.setText(cardapioSemana[1][7]);
        CARDAPIO_Saladas2.setText(cardapioSemana[1][8]);
        CARDAPIO_Saladas3.setText(cardapioSemana[1][9]);

        CARDAPIO_Bebidas1.setText(cardapioSemana[1][10]);
        CARDAPIO_Bebidas2.setText(cardapioSemana[1][11]);

        CARDAPIO_Sobremesas.setText(cardapioSemana[1][12]);

        //Quarta-feira
        CARDAPIO_Acompanhamento1.setText(cardapioSemana[2][0]);
        CARDAPIO_Acompanhamento2.setText(cardapioSemana[2][1]);

        CARDAPIO_Prato_Principal1.setText(cardapioSemana[2][2]);
        CARDAPIO_Prato_Principal2.setText(cardapioSemana[2][3]);

        CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[2][4]);
        CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[2][5]);

        CARDAPIO_Complementos.setText(cardapioSemana[2][6]);

        CARDAPIO_Saladas1.setText(cardapioSemana[2][7]);
        CARDAPIO_Saladas2.setText(cardapioSemana[2][8]);
        CARDAPIO_Saladas3.setText(cardapioSemana[2][9]);

        CARDAPIO_Bebidas1.setText(cardapioSemana[2][10]);
        CARDAPIO_Bebidas2.setText(cardapioSemana[2][11]);

        CARDAPIO_Sobremesas.setText(cardapioSemana[2][12]);

        //Quinta-feira
        CARDAPIO_Acompanhamento1.setText(cardapioSemana[3][0]);
        CARDAPIO_Acompanhamento2.setText(cardapioSemana[3][1]);

        CARDAPIO_Prato_Principal1.setText(cardapioSemana[3][2]);
        CARDAPIO_Prato_Principal2.setText(cardapioSemana[3][3]);

        CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[3][4]);
        CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[3][5]);

        CARDAPIO_Complementos.setText(cardapioSemana[3][6]);

        CARDAPIO_Saladas1.setText(cardapioSemana[3][7]);
        CARDAPIO_Saladas2.setText(cardapioSemana[3][8]);
        CARDAPIO_Saladas3.setText(cardapioSemana[3][9]);

        CARDAPIO_Bebidas1.setText(cardapioSemana[3][10]);
        CARDAPIO_Bebidas2.setText(cardapioSemana[3][11]);

        CARDAPIO_Sobremesas.setText(cardapioSemana[3][12]);

        //Quinta-feira
        CARDAPIO_Acompanhamento1.setText(cardapioSemana[4][0]);
        CARDAPIO_Acompanhamento2.setText(cardapioSemana[4][1]);

        CARDAPIO_Prato_Principal1.setText(cardapioSemana[4][2]);
        CARDAPIO_Prato_Principal2.setText(cardapioSemana[4][3]);

        CARDAPIO_Prato_Principal_OVO1.setText(cardapioSemana[4][4]);
        CARDAPIO_Prato_Principal_OVO2.setText(cardapioSemana[4][5]);

        CARDAPIO_Complementos.setText(cardapioSemana[4][6]);

        CARDAPIO_Saladas1.setText(cardapioSemana[4][7]);
        CARDAPIO_Saladas2.setText(cardapioSemana[4][8]);
        CARDAPIO_Saladas3.setText(cardapioSemana[4][9]);

        CARDAPIO_Bebidas1.setText(cardapioSemana[4][10]);
        CARDAPIO_Bebidas2.setText(cardapioSemana[4][11]);

        CARDAPIO_Sobremesas.setText(cardapioSemana[4][12]);

    }

    public Interface() {

        initComponents();
        setLocationRelativeTo(null);
        LimparCardapio();
        MostrarCardapioLimpo();

        TELA_Cardapio.setVisible(false);
        TELA_Login.setVisible(true);

        DiaDaSemana.setEnabled(false);

        btLOGOUT.setVisible(false);
        btEDITAR.setVisible(true);
        btSALVAR.setVisible(false);
        btCANCELAR.setVisible(false);
        btLIMPAR.setVisible(false);

        DiaDaSemana.setText("Segunda-feira");
        Estrela1.setEnabled(false);
        Estrela2.setEnabled(false);
        Estrela3.setEnabled(false);
        Estrela4.setEnabled(false);
        Estrela5.setEnabled(false);
        btAVALIAR.setEnabled(false);

        CARDAPIO_Acompanhamento1.setEnabled(false);
        CARDAPIO_Acompanhamento2.setEnabled(false);
        CARDAPIO_Prato_Principal1.setEnabled(false);
        CARDAPIO_Prato_Principal2.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(false);
        CARDAPIO_Complementos.setEnabled(false);
        CARDAPIO_Saladas1.setEnabled(false);
        CARDAPIO_Saladas2.setEnabled(false);
        CARDAPIO_Saladas3.setEnabled(false);
        CARDAPIO_Bebidas1.setEnabled(false);
        CARDAPIO_Bebidas2.setEnabled(false);
        CARDAPIO_Sobremesas.setEnabled(false);

        btVoltar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                indiceDiaAtual--; // Avançar um dia
                if (indiceDiaAtual < 0) {
                    indiceDiaAtual = 4; // Volta para segunda-feira se for sexta-feira
                }
                atualizarTextField();
                AtualizarCardapio();
            }
        });

        btAvançar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                indiceDiaAtual++; // Avançar um dia
                if (indiceDiaAtual >= 5) {
                    indiceDiaAtual = 0; // Volta para segunda-feira se for sexta-feira
                }
                atualizarTextField();
                AtualizarCardapio();
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        TELA_Cardapio = new javax.swing.JScrollPane();
        TELA_CARDAPIO = new javax.swing.JPanel();
        CARDAPIO_Acompanhamento2 = new javax.swing.JTextField();
        CARDAPIO_Acompanhamento1 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        CARDAPIO_Prato_Principal2 = new javax.swing.JTextField();
        CARDAPIO_Prato_Principal1 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        CARDAPIO_Prato_Principal_OVO2 = new javax.swing.JTextField();
        CARDAPIO_Prato_Principal_OVO1 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        CARDAPIO_Complementos = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        CARDAPIO_Saladas1 = new javax.swing.JTextField();
        CARDAPIO_Saladas2 = new javax.swing.JTextField();
        CARDAPIO_Saladas3 = new javax.swing.JTextField();
        CARDAPIO_Bebidas1 = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        CARDAPIO_Bebidas2 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        CARDAPIO_Sobremesas = new javax.swing.JTextField();
        btAVALIAR = new javax.swing.JButton();
        Estrela1 = new javax.swing.JToggleButton();
        Estrela2 = new javax.swing.JToggleButton();
        Estrela3 = new javax.swing.JToggleButton();
        Estrela4 = new javax.swing.JToggleButton();
        Estrela5 = new javax.swing.JToggleButton();
        btVoltar = new javax.swing.JButton();
        DiaDaSemana = new javax.swing.JTextField();
        btAvançar = new javax.swing.JButton();
        txtCARDAPIO = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btLIMPAR = new javax.swing.JButton();
        btLOGOUT = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        CARDAPIOnomedeusuario = new javax.swing.JLabel();
        btCANCELAR = new javax.swing.JButton();
        btSALVAR = new javax.swing.JButton();
        btEDITAR = new javax.swing.JButton();
        TELA_Login = new javax.swing.JPanel();
        CAMPOnomedeusuario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        CAMPOsenha = new javax.swing.JPasswordField();
        btLOGIN = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        TELA_Cardapio.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        TELA_Cardapio.setPreferredSize(new java.awt.Dimension(540, 430));

        TELA_CARDAPIO.setBackground(new java.awt.Color(255, 255, 255));
        TELA_CARDAPIO.setPreferredSize(new java.awt.Dimension(440, 800));

        CARDAPIO_Acompanhamento2.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Acompanhamento2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Acompanhamento2.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Acompanhamento2.setText("Feijão");
        CARDAPIO_Acompanhamento2.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Acompanhamento2.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Acompanhamento2.setPreferredSize(new java.awt.Dimension(162, 26));
        CARDAPIO_Acompanhamento2.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Acompanhamento2.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Acompanhamento2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Acompanhamento2ActionPerformed(evt);
            }
        });

        CARDAPIO_Acompanhamento1.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Acompanhamento1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Acompanhamento1.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Acompanhamento1.setText("Arroz branco/Integral");
        CARDAPIO_Acompanhamento1.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Acompanhamento1.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Acompanhamento1.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Acompanhamento1.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Acompanhamento1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Acompanhamento1ActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(244, 93, 72));
        jLabel22.setText("ACOMPANHAMENTOS");

        CARDAPIO_Prato_Principal2.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Prato_Principal2.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal2.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Prato_Principal2.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal2.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal2.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Prato_Principal2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Prato_Principal2ActionPerformed(evt);
            }
        });

        CARDAPIO_Prato_Principal1.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Prato_Principal1.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal1.setText("Filé de Frango ao molho branco");
        CARDAPIO_Prato_Principal1.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Prato_Principal1.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal1.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal1.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Prato_Principal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Prato_Principal1ActionPerformed(evt);
            }
        });

        jLabel23.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(244, 93, 72));
        jLabel23.setText("PRATO PRINCIPAL");

        CARDAPIO_Prato_Principal_OVO2.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal_OVO2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Prato_Principal_OVO2.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal_OVO2.setText("Feijão");
        CARDAPIO_Prato_Principal_OVO2.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Prato_Principal_OVO2.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal_OVO2.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal_OVO2.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Prato_Principal_OVO2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Prato_Principal_OVO2ActionPerformed(evt);
            }
        });

        CARDAPIO_Prato_Principal_OVO1.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal_OVO1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Prato_Principal_OVO1.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal_OVO1.setText("Fritada Espanhola");
        CARDAPIO_Prato_Principal_OVO1.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Prato_Principal_OVO1.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Prato_Principal_OVO1.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Prato_Principal_OVO1.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Prato_Principal_OVO1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Prato_Principal_OVO1ActionPerformed(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(244, 93, 72));
        jLabel24.setText("PRATO PRINCIPAL OVOLACTOVEGETARIANO");

        CARDAPIO_Complementos.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Complementos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Complementos.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Complementos.setText("Batata Palha");
        CARDAPIO_Complementos.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Complementos.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Complementos.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Complementos.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Complementos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_ComplementosActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(244, 93, 72));
        jLabel25.setText("COMPLEMENTOS");

        jLabel26.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(244, 93, 72));
        jLabel26.setText("SALADAS");

        CARDAPIO_Saladas1.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Saladas1.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas1.setText("Alface");
        CARDAPIO_Saladas1.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Saladas1.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas1.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas1.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Saladas1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Saladas1ActionPerformed(evt);
            }
        });

        CARDAPIO_Saladas2.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Saladas2.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas2.setText("Tomate em rodelas");
        CARDAPIO_Saladas2.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Saladas2.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas2.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas2.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Saladas2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Saladas2ActionPerformed(evt);
            }
        });

        CARDAPIO_Saladas3.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Saladas3.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas3.setText("Abobrinha cozida");
        CARDAPIO_Saladas3.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Saladas3.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Saladas3.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Saladas3.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Saladas3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Saladas3ActionPerformed(evt);
            }
        });

        CARDAPIO_Bebidas1.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Bebidas1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Bebidas1.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Bebidas1.setText("Suco de Manga");
        CARDAPIO_Bebidas1.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Bebidas1.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Bebidas1.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Bebidas1.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Bebidas1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Bebidas1ActionPerformed(evt);
            }
        });

        jLabel27.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(244, 93, 72));
        jLabel27.setText("BEBIDAS");

        CARDAPIO_Bebidas2.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Bebidas2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Bebidas2.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Bebidas2.setText("Suco de Manga s/ açucar");
        CARDAPIO_Bebidas2.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Bebidas2.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Bebidas2.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Bebidas2.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Bebidas2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_Bebidas2ActionPerformed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(244, 93, 72));
        jLabel28.setText("SOBREMESAS");

        CARDAPIO_Sobremesas.setBackground(new java.awt.Color(255, 255, 255));
        CARDAPIO_Sobremesas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        CARDAPIO_Sobremesas.setForeground(new java.awt.Color(0, 51, 51));
        CARDAPIO_Sobremesas.setText("Melão");
        CARDAPIO_Sobremesas.setCaretColor(new java.awt.Color(0, 0, 0));
        CARDAPIO_Sobremesas.setDisabledTextColor(new java.awt.Color(0, 51, 51));
        CARDAPIO_Sobremesas.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CARDAPIO_Sobremesas.setSelectionColor(new java.awt.Color(244, 93, 72));
        CARDAPIO_Sobremesas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CARDAPIO_SobremesasActionPerformed(evt);
            }
        });

        btAVALIAR.setBackground(new java.awt.Color(244, 93, 72));
        btAVALIAR.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btAVALIAR.setForeground(new java.awt.Color(248, 245, 242));
        btAVALIAR.setText("AVALIAR");

        Estrela1.setBackground(new java.awt.Color(248, 245, 242));
        Estrela1.setText("✦");

        Estrela2.setBackground(new java.awt.Color(248, 245, 242));
        Estrela2.setText("✦");

        Estrela3.setBackground(new java.awt.Color(248, 245, 242));
        Estrela3.setText("✦");

        Estrela4.setBackground(new java.awt.Color(248, 245, 242));
        Estrela4.setText("✦");

        Estrela5.setBackground(new java.awt.Color(248, 245, 242));
        Estrela5.setText("✦");

        btVoltar.setBackground(new java.awt.Color(7, 128, 128));
        btVoltar.setFont(new java.awt.Font("Segoe UI Black", 1, 9)); // NOI18N
        btVoltar.setForeground(new java.awt.Color(255, 255, 255));
        btVoltar.setText("<");
        btVoltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVoltarActionPerformed(evt);
            }
        });

        DiaDaSemana.setBackground(new java.awt.Color(7, 128, 128));
        DiaDaSemana.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        DiaDaSemana.setForeground(new java.awt.Color(255, 255, 255));
        DiaDaSemana.setDisabledTextColor(new java.awt.Color(255, 255, 255));
        DiaDaSemana.setPreferredSize(new java.awt.Dimension(64, 30));

        btAvançar.setBackground(new java.awt.Color(7, 128, 128));
        btAvançar.setFont(new java.awt.Font("Segoe UI Black", 1, 9)); // NOI18N
        btAvançar.setForeground(new java.awt.Color(255, 255, 255));
        btAvançar.setText(">");
        btAvançar.setMaximumSize(new java.awt.Dimension(25, 25));
        btAvançar.setMinimumSize(new java.awt.Dimension(25, 25));
        btAvançar.setPreferredSize(new java.awt.Dimension(25, 25));
        btAvançar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAvançarActionPerformed(evt);
            }
        });

        txtCARDAPIO.setBackground(new java.awt.Color(244, 93, 72));
        txtCARDAPIO.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 0, 40)); // NOI18N
        txtCARDAPIO.setForeground(new java.awt.Color(35, 35, 35));
        txtCARDAPIO.setText("CARDÁPIO!");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btLIMPAR.setBackground(new java.awt.Color(255, 255, 255));
        btLIMPAR.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btLIMPAR.setForeground(new java.awt.Color(35, 35, 35));
        btLIMPAR.setText("Limpar");
        btLIMPAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLIMPARActionPerformed(evt);
            }
        });

        btLOGOUT.setBackground(new java.awt.Color(255, 255, 255));
        btLOGOUT.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btLOGOUT.setForeground(new java.awt.Color(244, 93, 72));
        btLOGOUT.setText("LOGOUT");
        btLOGOUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLOGOUTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btLIMPAR)
                    .addComponent(btLOGOUT))
                .addGap(0, 57, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btLOGOUT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btLIMPAR)
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        CARDAPIOnomedeusuario.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        CARDAPIOnomedeusuario.setForeground(new java.awt.Color(35, 35, 35));
        CARDAPIOnomedeusuario.setText("NOME DE USUARIO");

        btCANCELAR.setBackground(new java.awt.Color(244, 93, 72));
        btCANCELAR.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btCANCELAR.setForeground(new java.awt.Color(255, 255, 255));
        btCANCELAR.setText("Cancelar");
        btCANCELAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCANCELARActionPerformed(evt);
            }
        });

        btSALVAR.setBackground(new java.awt.Color(7, 128, 128));
        btSALVAR.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btSALVAR.setForeground(new java.awt.Color(35, 35, 35));
        btSALVAR.setText("Salvar");
        btSALVAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSALVARActionPerformed(evt);
            }
        });

        btEDITAR.setBackground(new java.awt.Color(7, 128, 128));
        btEDITAR.setFont(new java.awt.Font("Segoe UI Black", 0, 12)); // NOI18N
        btEDITAR.setForeground(new java.awt.Color(35, 35, 35));
        btEDITAR.setText("Editar");
        btEDITAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEDITARActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TELA_CARDAPIOLayout = new javax.swing.GroupLayout(TELA_CARDAPIO);
        TELA_CARDAPIO.setLayout(TELA_CARDAPIOLayout);
        TELA_CARDAPIOLayout.setHorizontalGroup(
            TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                .addComponent(btAVALIAR)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Estrela1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Estrela2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Estrela3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Estrela4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Estrela5))
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(171, 171, 171))
                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TELA_CARDAPIOLayout.createSequentialGroup()
                                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btVoltar, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                                        .addComponent(CARDAPIOnomedeusuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                                        .addComponent(DiaDaSemana, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                        .addComponent(btAvançar, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(51, 51, 51)))
                                                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(btSALVAR, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(btCANCELAR, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                                .addGap(26, 26, 26)
                                                .addComponent(txtCARDAPIO)
                                                .addGap(0, 0, Short.MAX_VALUE))))
                                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                        .addComponent(jLabel22)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btEDITAR, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(CARDAPIO_Bebidas1)
                                    .addComponent(CARDAPIO_Saladas3)
                                    .addComponent(CARDAPIO_Saladas2)
                                    .addComponent(CARDAPIO_Saladas1)
                                    .addComponent(CARDAPIO_Complementos)
                                    .addComponent(CARDAPIO_Prato_Principal_OVO2)
                                    .addComponent(CARDAPIO_Prato_Principal_OVO1)
                                    .addComponent(CARDAPIO_Acompanhamento2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(CARDAPIO_Acompanhamento1)
                                    .addComponent(CARDAPIO_Prato_Principal1, javax.swing.GroupLayout.DEFAULT_SIZE, 511, Short.MAX_VALUE)
                                    .addComponent(CARDAPIO_Prato_Principal2)
                                    .addComponent(CARDAPIO_Bebidas2)
                                    .addComponent(CARDAPIO_Sobremesas))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(20, 20, 20))))
        );
        TELA_CARDAPIOLayout.setVerticalGroup(
            TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TELA_CARDAPIOLayout.createSequentialGroup()
                        .addComponent(txtCARDAPIO, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addComponent(CARDAPIOnomedeusuario)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btAvançar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btVoltar, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                            .addComponent(DiaDaSemana, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, TELA_CARDAPIOLayout.createSequentialGroup()
                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(TELA_CARDAPIOLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btCANCELAR)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btSALVAR)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(btEDITAR))
                        .addGap(5, 5, 5)))
                .addComponent(CARDAPIO_Acompanhamento1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addComponent(CARDAPIO_Acompanhamento2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Prato_Principal1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Prato_Principal2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Prato_Principal_OVO1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Prato_Principal_OVO2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Complementos, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Saladas1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Saladas2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Saladas3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Bebidas1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Bebidas2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CARDAPIO_Sobremesas, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(TELA_CARDAPIOLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Estrela1)
                    .addComponent(Estrela2)
                    .addComponent(Estrela3)
                    .addComponent(Estrela4)
                    .addComponent(Estrela5)
                    .addComponent(btAVALIAR))
                .addContainerGap(7, Short.MAX_VALUE))
        );

        TELA_Cardapio.setViewportView(TELA_CARDAPIO);

        TELA_Login.setBackground(new java.awt.Color(255, 255, 255));

        CAMPOnomedeusuario.setBackground(new java.awt.Color(255, 255, 255));
        CAMPOnomedeusuario.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        CAMPOnomedeusuario.setForeground(new java.awt.Color(35, 35, 35));
        CAMPOnomedeusuario.setCaretColor(new java.awt.Color(35, 35, 35));
        CAMPOnomedeusuario.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CAMPOnomedeusuario.setSelectionColor(new java.awt.Color(244, 93, 72));

        jLabel2.setFont(new java.awt.Font("Swis721 Blk BT", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(7, 128, 128));
        jLabel2.setText("Senha:");

        jLabel3.setFont(new java.awt.Font("Swis721 Blk BT", 0, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(7, 128, 128));
        jLabel3.setText("Nome de usuário:");

        CAMPOsenha.setBackground(new java.awt.Color(255, 255, 255));
        CAMPOsenha.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        CAMPOsenha.setForeground(new java.awt.Color(35, 35, 35));
        CAMPOsenha.setCaretColor(new java.awt.Color(35, 35, 35));
        CAMPOsenha.setSelectedTextColor(new java.awt.Color(255, 255, 255));
        CAMPOsenha.setSelectionColor(new java.awt.Color(244, 93, 72));

        btLOGIN.setBackground(new java.awt.Color(244, 93, 72));
        btLOGIN.setFont(new java.awt.Font("Swis721 Blk BT", 0, 18)); // NOI18N
        btLOGIN.setForeground(new java.awt.Color(255, 255, 255));
        btLOGIN.setText("Login");
        btLOGIN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLOGINActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Swis721 Blk BT", 0, 35)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(7, 128, 128));
        jLabel4.setText("QUEM TEM PRESSA, TEM ");

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/157 Sem Título.jpg"))); // NOI18N

        javax.swing.GroupLayout TELA_LoginLayout = new javax.swing.GroupLayout(TELA_Login);
        TELA_Login.setLayout(TELA_LoginLayout);
        TELA_LoginLayout.setHorizontalGroup(
            TELA_LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TELA_LoginLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(TELA_LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TELA_LoginLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(TELA_LoginLayout.createSequentialGroup()
                        .addGroup(TELA_LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btLOGIN, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(CAMPOsenha, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
                            .addComponent(CAMPOnomedeusuario)
                            .addComponent(jLabel3))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(TELA_LoginLayout.createSequentialGroup()
                .addGroup(TELA_LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TELA_LoginLayout.createSequentialGroup()
                        .addGap(173, 173, 173)
                        .addComponent(jLabel5))
                    .addGroup(TELA_LoginLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TELA_LoginLayout.setVerticalGroup(
            TELA_LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TELA_LoginLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(43, 43, 43)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CAMPOnomedeusuario, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CAMPOsenha, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btLOGIN, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(TELA_Login, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TELA_Cardapio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TELA_Login, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(TELA_Cardapio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CARDAPIO_Acompanhamento2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Acompanhamento2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Acompanhamento2ActionPerformed

    private void CARDAPIO_Acompanhamento1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Acompanhamento1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Acompanhamento1ActionPerformed

    private void CARDAPIO_Prato_Principal2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Prato_Principal2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Prato_Principal2ActionPerformed

    private void CARDAPIO_Prato_Principal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Prato_Principal1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Prato_Principal1ActionPerformed

    private void CARDAPIO_Prato_Principal_OVO2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Prato_Principal_OVO2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Prato_Principal_OVO2ActionPerformed

    private void CARDAPIO_Prato_Principal_OVO1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Prato_Principal_OVO1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Prato_Principal_OVO1ActionPerformed

    private void CARDAPIO_ComplementosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_ComplementosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_ComplementosActionPerformed

    private void CARDAPIO_Saladas1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Saladas1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Saladas1ActionPerformed

    private void CARDAPIO_Saladas2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Saladas2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Saladas2ActionPerformed

    private void CARDAPIO_Saladas3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Saladas3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Saladas3ActionPerformed

    private void CARDAPIO_Bebidas1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Bebidas1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Bebidas1ActionPerformed

    private void CARDAPIO_Bebidas2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_Bebidas2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_Bebidas2ActionPerformed

    private void CARDAPIO_SobremesasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CARDAPIO_SobremesasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CARDAPIO_SobremesasActionPerformed

    private void btEDITARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEDITARActionPerformed
        // TODO add your handling code here:
        btLOGOUT.setVisible(false);
        btEDITAR.setVisible(false);
        btSALVAR.setVisible(true);
        btCANCELAR.setVisible(true);
        btLIMPAR.setVisible(true);

        CARDAPIO_Acompanhamento1.setEnabled(true);
        CARDAPIO_Acompanhamento2.setEnabled(true);
        CARDAPIO_Prato_Principal1.setEnabled(true);
        CARDAPIO_Prato_Principal2.setEnabled(true);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(true);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(true);
        CARDAPIO_Complementos.setEnabled(true);
        CARDAPIO_Saladas1.setEnabled(true);
        CARDAPIO_Saladas2.setEnabled(true);
        CARDAPIO_Saladas3.setEnabled(true);
        CARDAPIO_Bebidas1.setEnabled(true);
        CARDAPIO_Bebidas2.setEnabled(true);
        CARDAPIO_Sobremesas.setEnabled(true);
        btVoltar.setEnabled(false);
        btAvançar.setEnabled(false);


    }//GEN-LAST:event_btEDITARActionPerformed

    private void btSALVARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSALVARActionPerformed
        // TODO add your handling code here:
        btLOGOUT.setVisible(true);
        btEDITAR.setVisible(true);
        btSALVAR.setVisible(false);
        btCANCELAR.setVisible(false);
        btLIMPAR.setVisible(false);

        ArmazenarCardapio();
        CARDAPIO_Acompanhamento1.setEnabled(false);
        CARDAPIO_Acompanhamento2.setEnabled(false);
        CARDAPIO_Prato_Principal1.setEnabled(false);
        CARDAPIO_Prato_Principal2.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(false);
        CARDAPIO_Complementos.setEnabled(false);
        CARDAPIO_Saladas1.setEnabled(false);
        CARDAPIO_Saladas2.setEnabled(false);
        CARDAPIO_Saladas3.setEnabled(false);
        CARDAPIO_Bebidas1.setEnabled(false);
        CARDAPIO_Bebidas2.setEnabled(false);
        CARDAPIO_Sobremesas.setEnabled(false);
        btVoltar.setEnabled(true);
        btAvançar.setEnabled(true);


    }//GEN-LAST:event_btSALVARActionPerformed

    private void btCANCELARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCANCELARActionPerformed
        // TODO add your handling code here:]

        btLOGOUT.setVisible(true);
        btEDITAR.setVisible(true);
        btSALVAR.setVisible(false);
        btCANCELAR.setVisible(false);
        btLIMPAR.setVisible(false);
        AtualizarCardapio();

        CARDAPIO_Acompanhamento1.setEnabled(false);
        CARDAPIO_Acompanhamento2.setEnabled(false);
        CARDAPIO_Prato_Principal1.setEnabled(false);
        CARDAPIO_Prato_Principal2.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(false);
        CARDAPIO_Complementos.setEnabled(false);
        CARDAPIO_Saladas1.setEnabled(false);
        CARDAPIO_Saladas2.setEnabled(false);
        CARDAPIO_Saladas3.setEnabled(false);
        CARDAPIO_Bebidas1.setEnabled(false);
        CARDAPIO_Bebidas2.setEnabled(false);
        CARDAPIO_Sobremesas.setEnabled(false);
        btVoltar.setEnabled(true);
        btAvançar.setEnabled(true);

    }//GEN-LAST:event_btCANCELARActionPerformed

    private void btVoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVoltarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btVoltarActionPerformed

    private void btAvançarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAvançarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btAvançarActionPerformed

    private void btLIMPARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLIMPARActionPerformed
        // TODO add your handling code here:

        String DiaAtual = DiaDaSemana.getText();
        Object[] options = {"SIM", "NÃO"};
        int resposta = JOptionPane.showOptionDialog(this,
                "Deseja mesmo limpar o cárdapio da " + DiaAtual + " ?\nNão será possível recuperar os campos preenchidos.",
                "Confirmação",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (resposta == JOptionPane.YES_OPTION) {
            LimparDiaCardapio();

            JOptionPane.showMessageDialog(this, "Limpando...");
        } else {
            JOptionPane.showMessageDialog(this, "Operação cancelada.");
        }

    }//GEN-LAST:event_btLIMPARActionPerformed

    private void btLOGOUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLOGOUTActionPerformed
        // TODO add your handling code here:
        CAMPOnomedeusuario.setText(null);
        CAMPOsenha.setText(null);
        CARDAPIOnomedeusuario.setText(null);
        nomeUsuario = null;
        senha = null;

        /*  btEDITAR.setVisible(true);
        btSALVAR.setVisible(false);
        btCANCELAR.setVisible(false);
        btLIMPAR.setVisible(false);

        CARDAPIO_Acompanhamento1.setEnabled(false);
        CARDAPIO_Acompanhamento2.setEnabled(false);
        CARDAPIO_Prato_Principal1.setEnabled(false);
        CARDAPIO_Prato_Principal2.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(false);
        CARDAPIO_Complementos.setEnabled(false);
        CARDAPIO_Saladas1.setEnabled(false);
        CARDAPIO_Saladas2.setEnabled(false);
        CARDAPIO_Saladas3.setEnabled(false);
        CARDAPIO_Bebidas1.setEnabled(false);
        CARDAPIO_Bebidas2.setEnabled(false);
        CARDAPIO_Sobremesas.setEnabled(false);
        btVoltar.setEnabled(true);
        btAvançar.setEnabled(true);
         */
        TELA_Cardapio.setVisible(false);
        TELA_Login.setVisible(true);
    }//GEN-LAST:event_btLOGOUTActionPerformed

    private void btLOGINActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLOGINActionPerformed
        // TODO add your handling code here:
        nomeUsuario = CAMPOnomedeusuario.getText();
        senha = CAMPOsenha.getText();

        if (nomeUsuario.isEmpty() || senha.isEmpty()) {
            // Exibindo mensagem de erro
            JOptionPane.showMessageDialog(this, "Por favor, preencha todos os campos para realizar o login.",
                    "Erro de Login", JOptionPane.ERROR_MESSAGE);
            return; // Encerrando o método sem realizar o login

        }
        CARDAPIOnomedeusuario.setText("Boa apetite " + nomeUsuario);
        TELA_Cardapio.setVisible(true);
        TELA_Login.setVisible(false);
        btLOGOUT.setVisible(true);
        btEDITAR.setVisible(true);
        btSALVAR.setVisible(false);
        btCANCELAR.setVisible(false);
        btLIMPAR.setVisible(false);

        CARDAPIO_Acompanhamento1.setEnabled(false);
        CARDAPIO_Acompanhamento2.setEnabled(false);
        CARDAPIO_Prato_Principal1.setEnabled(false);
        CARDAPIO_Prato_Principal2.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO1.setEnabled(false);
        CARDAPIO_Prato_Principal_OVO2.setEnabled(false);
        CARDAPIO_Complementos.setEnabled(false);
        CARDAPIO_Saladas1.setEnabled(false);
        CARDAPIO_Saladas2.setEnabled(false);
        CARDAPIO_Saladas3.setEnabled(false);
        CARDAPIO_Bebidas1.setEnabled(false);
        CARDAPIO_Bebidas2.setEnabled(false);
        CARDAPIO_Sobremesas.setEnabled(false);
        btVoltar.setEnabled(true);
        btAvançar.setEnabled(true);

    }//GEN-LAST:event_btLOGINActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField CAMPOnomedeusuario;
    private javax.swing.JPasswordField CAMPOsenha;
    private javax.swing.JTextField CARDAPIO_Acompanhamento1;
    private javax.swing.JTextField CARDAPIO_Acompanhamento2;
    private javax.swing.JTextField CARDAPIO_Bebidas1;
    private javax.swing.JTextField CARDAPIO_Bebidas2;
    private javax.swing.JTextField CARDAPIO_Complementos;
    private javax.swing.JTextField CARDAPIO_Prato_Principal1;
    private javax.swing.JTextField CARDAPIO_Prato_Principal2;
    private javax.swing.JTextField CARDAPIO_Prato_Principal_OVO1;
    private javax.swing.JTextField CARDAPIO_Prato_Principal_OVO2;
    private javax.swing.JTextField CARDAPIO_Saladas1;
    private javax.swing.JTextField CARDAPIO_Saladas2;
    private javax.swing.JTextField CARDAPIO_Saladas3;
    private javax.swing.JTextField CARDAPIO_Sobremesas;
    private javax.swing.JLabel CARDAPIOnomedeusuario;
    private javax.swing.JTextField DiaDaSemana;
    private javax.swing.JToggleButton Estrela1;
    private javax.swing.JToggleButton Estrela2;
    private javax.swing.JToggleButton Estrela3;
    private javax.swing.JToggleButton Estrela4;
    private javax.swing.JToggleButton Estrela5;
    private javax.swing.JPanel TELA_CARDAPIO;
    private javax.swing.JScrollPane TELA_Cardapio;
    private javax.swing.JPanel TELA_Login;
    private javax.swing.JButton btAVALIAR;
    private javax.swing.JButton btAvançar;
    private javax.swing.JButton btCANCELAR;
    private javax.swing.JButton btEDITAR;
    private javax.swing.JButton btLIMPAR;
    private javax.swing.JButton btLOGIN;
    private javax.swing.JButton btLOGOUT;
    private javax.swing.JButton btSALVAR;
    private javax.swing.JButton btVoltar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel txtCARDAPIO;
    // End of variables declaration//GEN-END:variables
}
