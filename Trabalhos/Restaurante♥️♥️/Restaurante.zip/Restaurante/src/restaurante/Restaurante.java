package restaurante;

import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Restaurante {

    public static void main(String[] args) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
       
    

        
            
       
        }
    }

